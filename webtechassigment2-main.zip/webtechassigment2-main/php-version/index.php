<?php
// Student Registration Form - PHP version
$today = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Registration | RVITM (PHP)</title>
  <link rel="stylesheet" href="style.css">
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="validation.js" defer></script>
</head>
<body>
  <main class="page-shell">
    <nav class="topbar">
      <a class="brand" href="index.php"><span class="brand-mark">R</span><span><strong>RVITM</strong><small>STUDENT PORTAL</small></span></a>
      <span class="secure-label"><span class="live-dot"></span> PHP REGISTRATION PORTAL</span>
    </nav>
    <section class="hero">
      <div class="eyebrow"><span></span> ONLINE APPLICATION</div>
      <h1>Start your next<br><span>chapter here.</span></h1>
      <p>Complete the form below to submit your student registration details. All fields marked with an asterisk are required.</p>
      <div class="hero-meta"><span>01 — YOUR DETAILS</span><span>02 — REVIEW & SUBMIT</span></div>
      <div class="progress-track"><span></span></div>
    </section>
    <section class="form-card">
      <div class="card-heading"><div><div class="section-kicker">APPLICATION FORM / 2026–27</div><h2>Personal information</h2></div><span class="required-note"><b>*</b> REQUIRED FIELDS</span></div>
      <form id="registrationForm" action="process.php" method="POST">
        <div class="form-grid">
          <div class="field full"><label for="fullName">Full name <b>*</b></label><input id="fullName" name="fullName" type="text" placeholder="Enter your full name" required maxlength="100"><small class="error-message"></small></div>
          <div class="field"><label for="email">Email address <b>*</b></label><input id="email" name="email" type="email" placeholder="you@example.com" required maxlength="150"><small class="error-message"></small></div>
          <div class="field"><label for="phone">Phone number <b>*</b></label><input id="phone" name="phone" type="tel" placeholder="+91 98765 43210" required maxlength="20"><small class="error-message"></small></div>
          <div class="field"><label for="dob">Date of birth <b>*</b></label><input id="dob" name="dob" type="date" max="<?php echo htmlspecialchars($today, ENT_QUOTES, 'UTF-8'); ?>" required><small class="error-message"></small></div>
          <div class="field"><label for="gender">Gender <b>*</b></label><select id="gender" name="gender" required><option value="">Select an option</option><option>Male</option><option>Female</option><option>Other</option><option>Prefer not to say</option></select><small class="error-message"></small></div>
          <div class="field"><label for="course">Course / programme <b>*</b></label><select id="course" name="course" required><option value="">Choose your programme</option><option>Computer Science & Engineering</option><option>Information Science & Engineering</option><option>Electronics & Communication Engineering</option><option>Artificial Intelligence & Machine Learning</option><option>Other</option></select><small class="error-message"></small></div>
          <div class="field"><label for="year">Year of study <b>*</b></label><select id="year" name="year" required><option value="">Select year</option><option>1st Year</option><option>2nd Year</option><option>3rd Year</option><option>4th Year</option></select><small class="error-message"></small></div>
          <div class="field full"><label for="address">Address <b>*</b></label><textarea id="address" name="address" rows="3" placeholder="House / street, area, city, state, PIN code" required maxlength="500"></textarea><small class="error-message"></small></div>
        </div>
        <label class="consent"><input id="consent" name="consent" type="checkbox" value="yes" required><span>I confirm that the information provided above is accurate and complete.</span></label>
        <small class="consent-error" aria-live="polite"></small>
        <button class="submit-button" type="submit"><span>Submit application</span><span class="button-arrow">↗</span></button>
        <p class="privacy-note">Your information is processed by the PHP application.</p>
      </form>
    </section>
    <footer><span>© 2026 RVITM · STUDENT REGISTRATION</span><span>HTML · CSS · JAVASCRIPT · jQUERY · PHP</span></footer>
  </main>
</body>
</html>